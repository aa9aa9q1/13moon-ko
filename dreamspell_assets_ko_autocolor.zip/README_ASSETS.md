# Dreamspell Asset Pack (KO, Auto-Color)

구성:
- `src/assets/seals/*.svg` (20) — 문양
- `src/assets/tones/*.svg` (13) — 톤
- `src/assets/moons/*.svg` (13) — 달
- `src/assets/meta/mapping.json` — 이름/클래스 매핑
- `src/assets/dreamspell.css` — 자동 색상 입히기

## 사용 예시 (HTML)
<link rel="stylesheet" href="/src/assets/dreamspell.css" />
<img src="/src/assets/seals/03_blue-night.svg" class="seal-blue icon-48" alt="파란 밤">
<img src="/src/assets/tones/13.svg" class="icon-48" alt="톤 13 우주">
<img src="/src/assets/moons/04.svg" class="icon-48" alt="4 자기(형태)의 달">

## 비고
- SVG들은 stroke/fill에 `currentColor`를 쓰므로, 부모 color나 `.seal-****` 클래스로 자동 착색됩니다.
- 이 세트는 '정확한 드림스펠 공식 문양'을 단순화한 **미니멀 버전**입니다.